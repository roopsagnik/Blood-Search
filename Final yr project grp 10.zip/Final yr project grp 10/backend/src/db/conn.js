const mongoose = require('mongoose');

mongoose.connect("mongodb+srv://sreehariroy273:WQhm84f9gL7kyM0H@cluster0.ckgu6b8.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0", {
    useNewUrlParser: true,
    useUnifiedTopology: true
    
}).then(() => {
    console.log(`connection successful`);
}).catch((err) => {
    console.log(`no connection`);
})