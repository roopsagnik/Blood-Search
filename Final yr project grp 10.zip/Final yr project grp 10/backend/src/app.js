var isFileUploaded=false;
const express = require("express");
const ejs = require("ejs");
const multer = require('multer');
const path = require("path");
const app = express();
const fs = require('fs');

require("./db/conn");
const Register = require("./models/registers");
const signup = require("./models/signup");
const { json } = require("express");

const port = process.env.PORT || 5000;

const static_path = path.join(__dirname, "../public");

app.use(express.json());
app.use(express.urlencoded({ extended: false }));

app.use(express.static(static_path));

// Remove the routes that attempt to render HTML files
app.get("/", (req, res) => {
     res.send("index.html");
 });
app.route("/signup")
 .get( (req, res) => {
    res.send("profile.html");
 })

 .post( async(req, res) => {
    try {
        const newsignup = new signup({
            email: req.body.email,
            password: req.body.password
        });

        const signup1 = await newsignup.save();
        res.status(201).redirect("/profile.html"); // Redirect to profile page after successful signup
    } catch (error) {
        console.error(error);
        res.status(400).send("Registration failed");
    }
});


// get a new user in our database
app.post("/register", async(req, res) => {
    try {
        const newRegister = new Register({
            name: req.body.name,
            age: req.body.age,
            gender: req.body.gender,
            guardianname: req.body.guardianname,
            phone: req.body.phone,
            email: req.body.email,
            medicalcontext: req.body.medicalcontext,
            bloodtype: req.body.bloodtype,
            address: req.body.address,
            district: req.body.district,
            state: req.body.state,
            pincode: req.body.pincode
        });
        
        

        const registered = await newRegister.save();
        console.log(registered);
            res.redirect("/");
       
        
    } catch (error) {
        console.log(error);
        res.status(400).json({ error: "Registration failed" });
    }
});

// login check

app.get("/signin", (req, res) => {
    res.send("sign_in.html");
});

app.post("/signin", async(req, res) => {
    try{

        const email = req.body.email;
        const password = req.body.password;

        const useremail = await signup.findOne({email:email});

        if (!useremail) {
            res.status(401).send("User not found");
            return;
        }

        if (!password) {
            res.status(401).send("Password not found");
            return;
        }

        if(useremail.password === password) {
            res.redirect("index.html");//status(201).render("index.html");
        } else {
            res.status(401).send("invalid login details");
        }

    } catch (error) {
        res.status(400).send("invalid login ");
        console.log(error);
    }
});



app.use(express.static(path.join(__dirname, 'public')));
app.engine('ejs', require('ejs').renderFile);
app.set('view engine', 'ejs');
// Set 'views' directory for any views 
// being rendered res.render()
app.set('views', path.join(__dirname, ''));
app.use('/form', express.static(__dirname + '/index.html'));
app.set('view engine', '.ejs');



const storage = multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, 'D:/reports'); // Set destination folder
    },
    filename: function (req, file, cb) {
      cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
    }
  });
  
  // Initialize upload
  const upload = multer({
    storage: storage,
    limits: { fileSize: 10000000 }, // Set file size limit (10MB)
  }).fields([
    { name: 'bloodGroupReport', maxCount: 1 },
    { name: 'bodyCheckupReport', maxCount: 1 }
  ]);
  
  // Handle POST request to upload reports
  app.post('/upload', (req, res) => {
    upload(req, res, (err) => {
      if (err) {
        console.error(err);
        return res.sendStatus(500);
      }
      res.sendStatus(200);
    });
  });
  
  // Serve index.html
  app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'home.html'));
  });

  app.listen(port, () => {
    console.log(`server is running at port no ${port}`);
});
  


  