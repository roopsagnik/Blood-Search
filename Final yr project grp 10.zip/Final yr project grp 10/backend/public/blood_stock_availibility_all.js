
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.11.1/firebase-app.js";
import { getFirestore, collection, getDocs } from "https://www.gstatic.com/firebasejs/10.11.1/firebase-firestore.js"; // Add this line to import Firestore

const firebaseConfig = {



  apiKey: "AIzaSyA0cZ83ZELot8u2VkIwIiRoyvCUjVzN7gA",

  authDomain: "bloodbank-db773.firebaseapp.com",

  projectId: "bloodbank-db773",

  storageBucket: "bloodbank-db773.appspot.com",

  messagingSenderId: "752679457735",

  appId: "1:752679457735:web:ce7fa800a6e8a6ff3b3fe2"

};


const app = initializeApp(firebaseConfig);
const db = getFirestore(app); 
const arr = [];

async function fetchDataFromFirestore() {
  try {
    const querySnapshot = await getDocs(collection(db, 'BloodSearching')); 
    querySnapshot.forEach((doc) => {
      // console.log(`${doc.id} => ${JSON.stringify(doc.data())}`);
      try {
        arr.push(doc.data()); 
      } catch (error) {
        console.error("Error parsing JSON data: ", error);
       
      }
    });
    // console.log(arr);
  } catch (error) {
    console.error("Error fetching documents: ", error);
  }
}


fetchDataFromFirestore();





var searchItem = document.getElementById('search');
console.log(searchItem)
searchItem.addEventListener('click', () => {
 Search();
  
})



function Search() {
  var state = document.getElementById("stateSelect").value;
  var bloodGroup = document.getElementById("blood-group").value;
 
  for (let i = 0; i < arr.length; i++) {
    console.log("state->2:", arr[i].State);
    console.log("state->1:", state);
    console.log("bloodComponent->1:", bloodGroup);
    console.log("bloodComponent->2:", arr[i].BloodGroup);
    
    if (state == arr[i].State && bloodGroup == arr[i].BloodGroup ) {
     
      showData(arr[i].BloodBankName ,  arr[i].Availability , arr[i].Category )
    }

  }
}


function showData(BloodBankName, Availability, Category) {
 
  var tbody = document.getElementById('tbody1');


  var newRow = document.createElement('tr');
 let sn = 1;
 
  var snoCell = document.createElement('td');
  snoCell.textContent = sn++; 
  newRow.appendChild(snoCell);

  var bloodBankCell = document.createElement('td');
  bloodBankCell.textContent = BloodBankName;
  newRow.appendChild(bloodBankCell);

  var availabilityCell = document.createElement('td');
  availabilityCell.textContent = Availability;
  newRow.appendChild(availabilityCell);

  var categoryCell = document.createElement('td');
  categoryCell.textContent = Category;
  newRow.appendChild(categoryCell);

  
  tbody.appendChild(newRow);
}

