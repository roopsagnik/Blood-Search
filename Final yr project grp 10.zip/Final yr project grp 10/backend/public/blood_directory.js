import { initializeApp } from "https://www.gstatic.com/firebasejs/10.11.1/firebase-app.js";
import { getFirestore, collection, getDocs } from "https://www.gstatic.com/firebasejs/10.11.1/firebase-firestore.js"; 

const firebaseConfig = {
  apiKey: "AIzaSyBXFnQ-ImARXDkIaceMmAl-xqxWC6amEso",

  authDomain: "bloodbankdirectory-26b93.firebaseapp.com",

  projectId: "bloodbankdirectory-26b93",

  storageBucket: "bloodbankdirectory-26b93.appspot.com",

  messagingSenderId: "243479183199",

  appId: "1:243479183199:web:0c3a6f93dfc456dc1ac0ea"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app); 
const arr = [];

async function fetchDataFromFirestore() {
    try {
      const querySnapshot = await getDocs(collection(db, 'BloodDirectory')); 
      querySnapshot.forEach((doc) => {
        // console.log(`${doc.id} => ${JSON.stringify(doc.data())}`);
        try {
          arr.push(doc.data()); 
        } catch (error) {
          console.error("Error parsing JSON data: ", error);
         
        }
      });
      console.log(arr);
    } catch (error) {
      console.error("Error fetching documents: ", error);
    }
  }


  fetchDataFromFirestore();


var searchItem = document.getElementById('search');
console.log(searchItem)
searchItem.addEventListener('click', () => {
 Search();
  
})

function Search() {
    var state = document.getElementById("stateSelect").value;
    var district = document.getElementById("districtSelect").value;
    var hospital = document.getElementById("blood-bank-or-hospital-name").value;
    
    //=----=-=-=//

    for (let i = 0; i < arr.length; i++) {
        console.log("state->2:", arr[i].State);
        console.log("state->1:", state);
        console.log("district->1:", district);
        console.log("district->2:", arr[i].District);
        console.log("hospital->1:", hospital);
        console.log("hospital->2:", arr[i].Hospital);
        
        if (state == arr[i].State && district == arr[i].District && hospital == arr[i].Hospital) {
         
          showData(arr[i].Hospital , arr[i].Address, arr[i].Phone , arr[i].Category , arr[i].Stock )
        }
        // else {
        //   document.getElementById("tbody1").innerHTML = "NO DATA FOUND !!";
        //   document
        //     .getElementById("tbody1")
        //     .classList.add("text-white", "fs-1", "text-center");
        //   document.getElementById("tbody1").style.fontSize = "30px";
        // }
    
      }
}

function showData(Hospital, Address, Phone, Category, Stock) {
 
    var tbody = document.getElementById('tbody1');
  
  
    var newRow = document.createElement('tr');
   let sn = 1;
   
    var snoCell = document.createElement('td');
    snoCell.textContent = sn++; 
    newRow.appendChild(snoCell);
  
    var hospitalCell = document.createElement('td');
    hospitalCell.textContent = Hospital;
    newRow.appendChild( hospitalCell);

    var addressCell = document.createElement('td');
    addressCell.textContent = Address;
    newRow.appendChild(addressCell);

    var phoneCell = document.createElement('td');
    phoneCell.textContent = Phone;
    newRow.appendChild(phoneCell);

    var categoryCell = document.createElement('td');
    categoryCell.textContent = Category;
    newRow.appendChild(categoryCell);
  
    var stockCell = document.createElement('td');
    stockCell.textContent = Stock;
    newRow.appendChild(stockCell);
  
   

  
    
    tbody.appendChild(newRow);
  }